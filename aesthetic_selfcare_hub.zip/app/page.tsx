'use client'
import React from 'react'
import FocusOfDay from '../components/FocusOfDay'
import HabitTrackerGrid from '../components/HabitTrackerGrid'
import MindfulnessBox from '../components/MindfulnessBox'
import MoodTracker from '../components/MoodTracker'
import WheelOfLife from '../components/WheelOfLife'
import VisionBoard from '../components/VisionBoard'

export default function Page() {
  const today = new Date().toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
  return (
    <div>
      <header className="mb-6">
        <h1 className="font-serif text-3xl">Привет — сегодня {today}</h1>
        <p className="mt-2 text-sm text-coffee/80">Добро пожаловать в твой уютный дневник здоровья</p>
      </header>

      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <FocusOfDay />
          <div className="glass p-4 rounded-3xl">
            <HabitTrackerGrid />
          </div>
          <MindfulnessBox />
        </div>

        <aside className="space-y-6">
          <div className="glass p-4 rounded-3xl">
            <MoodTracker />
          </div>
          <div className="glass p-4 rounded-3xl">
            <WheelOfLife />
          </div>
          <div className="glass p-4 rounded-3xl">
            <VisionBoard />
          </div>
        </aside>
      </section>
    </div>
  )
}
