'use client'
import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'

const DAYS = Array.from({length:31}, (_,i)=>i+1)

type Habit = {
  id: string
  name: string
  color?: string
}

// Demo habits — in real app these come from Supabase
const DEFAULT_HABITS: Habit[] = [
  { id: 'h1', name: 'Утренняя зарядка', color: 'sand' },
  { id: 'h2', name: 'Вода 2л', color: 'rose-dust' },
  { id: 'h3', name: 'Медитация', color: 'sand' }
]

export default function HabitTrackerGrid() {
  const [habits, setHabits] = useState<Habit[]>(DEFAULT_HABITS)
  const [logs, setLogs] = useState<Record<string, boolean>>({})

  useEffect(()=> {
    // load from localStorage as fallback
    const ls = localStorage.getItem('habitLogs')
    if (ls) setLogs(JSON.parse(ls))
  },[])

  useEffect(()=> {
    localStorage.setItem('habitLogs', JSON.stringify(logs))
  },[logs])

  function toggle(habitId:string, day:number) {
    const key = `${habitId}_${day}`
    setLogs(prev => {
      const next = {...prev, [key]: !prev[key]}
      return next
    })
  }

  function rowProgress(habitId:string){
    const count = DAYS.reduce((acc, d) => acc + (logs[`${habitId}_${d}`] ? 1 : 0), 0)
    return `${count}/${DAYS.length}`
  }

  return (
    <div>
      <h3 className="font-serif text-xl mb-3">Tracker привычек</h3>
      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead>
            <tr className="text-left text-sm text-coffee/70">
              <th className="pr-4">Привычки</th>
              <th>
                <div className="flex gap-1">
                  {DAYS.map(d=>(
                    <div key={d} className="w-6 text-center">{d}</div>
                  ))}
                </div>
              </th>
              <th className="pl-4">Прогресс</th>
            </tr>
          </thead>
          <tbody>
            {habits.map(h=>{
              return (
                <tr key={h.id} className="align-top">
                  <td className="pr-4 py-2 w-48 sticky left-0 bg-paper">
                    <div className="flex items-center gap-2">
                      <div className={\`w-3 h-3 rounded-full bg-\${h.color}\`}></div>
                      <div className="text-sm">{h.name}</div>
                    </div>
                  </td>
                  <td>
                    <div className="flex gap-1">
                      {DAYS.map(d=>{
                        const key = \`\${h.id}_\${d}\`
                        const active = !!logs[key]
                        return (
                          <motion.button
                            key={key}
                            onClick={()=>toggle(h.id,d)}
                            whileTap={{ scale: 0.95 }}
                            className={\`w-6 h-6 rounded-md transition-colors no-outline \${active ? 'opacity-100' : 'bg-white/60'}\`}
                            style={{
                              backgroundColor: active ? (h.color === 'rose-dust' ? '#BC8F8F' : '#D4A373') : undefined,
                              boxShadow: active ? '0 2px 8px rgba(0,0,0,0.08)' : undefined
                            }}
                            aria-pressed={active}
                            title={\`\${h.name} — \${d}\`}
                          />
                        )
                      })}
                    </div>
                  </td>
                  <td className="pl-4 text-sm">{rowProgress(h.id)}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
