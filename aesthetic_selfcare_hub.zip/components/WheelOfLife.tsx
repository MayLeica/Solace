'use client'
import React, { useState } from 'react'
import { motion } from 'framer-motion'

const SEGMENTS = ['Здоровье','Работа','Отношения','Финансы','Развитие','Отдых']

export default function WheelOfLife(){
  const [levels, setLevels] = useState<number[]>([6,5,7,4,6,5])

  function setLevel(i:number, v:number){
    const next = [...levels]
    next[i] = v
    setLevels(next)
  }

  // simple radial visualization using polygons
  const max = 10
  const angle = (2*Math.PI)/SEGMENTS.length

  return (
    <div>
      <h3 className="font-serif text-lg mb-2">Wheel of Life</h3>
      <div className="flex gap-4 items-center">
        <svg width="180" height="180" viewBox="-90 -90 180 180">
          <g transform="rotate(-90)">
            <motion.polygon
              points={levels.map((lv,i)=>{
                const r = 40 + (lv/max)*40
                const a = i*angle
                const x = Math.cos(a)*r
                const y = Math.sin(a)*r
                return `${x},${y}`
              }).join(' ')}
              animate={{ opacity: 1 }}
              style={{ fill: 'rgba(212,163,115,0.85)', stroke: '#8a6f53', strokeWidth: 0.5 }}
            />
            {SEGMENTS.map((s,i)=>{
              const r = 70
              const a = i*angle
              const x = Math.cos(a)*r
              const y = Math.sin(a)*r
              return <text key={s} x={x} y={y} fontSize="9" textAnchor="middle" alignmentBaseline="middle">{s}</text>
            })}
          </g>
        </svg>

        <div>
          {SEGMENTS.map((s,i)=>(
            <div key={s} className="flex items-center gap-2 mb-2">
              <div className="w-28 text-sm">{s}</div>
              <input type="range" min={0} max={10} value={levels[i]} onChange={(e)=>setLevel(i, Number(e.target.value))} />
              <div className="w-6 text-sm text-right">{levels[i]}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
